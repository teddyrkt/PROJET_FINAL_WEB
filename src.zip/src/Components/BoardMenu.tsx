import { User, Project } from '../../types';
import { useState } from 'react';

type Props = {
  onClose: () => void
  onChangeBackground: (bg: string) => void

  currentUser: User
  project: Project
  users: User[]
  onUpdateProject: (project: Project) => void
}

export default function BoardMenu({
  onClose,
  onChangeBackground,
  currentUser,
  project,
  users,
  onUpdateProject
}: Props) {

  const [selectedUsers, setSelectedUsers] = useState<number[]>(project.userIds);
  const [isEditingAccess, setIsEditingAccess] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()

    reader.onload = () => {
      const imageUrl = reader.result as string
      onChangeBackground(imageUrl)
    }

    reader.readAsDataURL(file)
  }

  return (
    <div className="board-menu-overlay" onClick={onClose}>
      <div className="board-menu" onClick={(e) => e.stopPropagation()}>

        <div className="menu-header">
          <span>Menu</span>
          <button onClick={onClose}>✕</button>
        </div>

        <h4>Changer le fond d'écran</h4>

        <div className="background-grid">
          <div className="bg-option bg1" onClick={() => onChangeBackground('bg1')} />
          <div className="bg-option bg2" onClick={() => onChangeBackground('bg2')} />
          <div className="bg-option bg3" onClick={() => onChangeBackground('bg3')} />
          <div className="bg-option bg4" onClick={() => onChangeBackground('bg4')} />
        </div>

        {/* IMPORT IMAGE */}
        <label className="upload-background">
          Importer une image
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
          />
        </label>

        {/* 👥 TOUS VOIENT LES MEMBRES */}
        <h4>Membres du projet</h4>

        <div className="user-checkbox-list">
          {users
            .filter(user => project.userIds.includes(user.id))
            .map(user => (
              <div
                key={user.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  marginTop: "5px"
                }}
              >
                <span>{user.name}</span>
                {user.id === project.ownerId && " 👑"}
              </div>
            ))}
        </div>

          {/* 👑 OWNER */}
          {currentUser.id === project.ownerId && (

            !isEditingAccess ? (

              <button
                className="btn-save"
                style={{ marginTop: "10px" }}
                onClick={() => setIsEditingAccess(true)}
              >
                Modifier les accès
              </button>

            ) : (

              <>
                <h4 style={{ marginTop: "15px" }}>Modifier les accès</h4>

                <div className="user-checkbox-list">
                  {users.map(user => (
                    <label key={user.id}>
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.id)}
                        disabled={user.id === project.ownerId}
                        onChange={() => {
                          setSelectedUsers(prev =>
                            prev.includes(user.id)
                              ? prev.filter(id => id !== user.id)
                              : [...prev, user.id]
                          );
                        }}
                      />
                      {" "}{user.name}
                      {user.id === project.ownerId && " 👑"}
                    </label>
                  ))}
                </div>

                <button
                  className="btn-save"
                  onClick={() => {
                    const updated = {
                      ...project,
                      userIds: selectedUsers
                    };

                    onUpdateProject(updated);

                    // 👇 revenir en mode normal
                    setIsEditingAccess(false);
                  }}
                >
                  Sauvegarder
                </button>
              </>
            )
          )}

      </div>
    </div>
  )
}